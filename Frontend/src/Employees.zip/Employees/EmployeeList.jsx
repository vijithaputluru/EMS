import React, { useEffect, useMemo, useState } from "react";
import "./EmployeeList.css";
import { useNavigate } from "react-router-dom";
import api from "../api/axiosInstance";
import { API_ENDPOINTS } from "../api/endpoints";
import SalaryStructureCard from "../components/SalaryStructureCard";
import useSalaryStructure from "../hooks/useSalaryStructure";
import {
  SALARY_MIN,
  buildSalaryBreakupPayload,
} from "../utils/salaryStructure";

const initialEmployeeForm = {
  id: "",
  originalId: "",
  name: "",
  email: "",
  dept: "",
  roleId: "",
  status: "",
  joined: "",
};

const extractCollection = (response) => {
  const payload = response?.data;

  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.data?.$values)) return payload.data.$values;
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload?.$values)) return payload.$values;

  return [];
};

const normalizeRoleOptions = (response) =>
  extractCollection(response).map((role) => ({
    roleId: role.roleId ?? role.id ?? role.role_Id ?? "",
    roleName: role.roleName ?? role.name ?? role.role ?? "",
  }));

const normalizeDepartmentOptions = (response) =>
  extractCollection(response).map((dept) => ({
    id: dept.id ?? dept.departmentId ?? dept.department_Id ?? dept.departmentName,
    departmentName: dept.departmentName ?? dept.name ?? dept.department ?? "",
  }));

const formatCurrency = (value) => {
  if (value === null || value === undefined || value === "" || Number.isNaN(Number(value))) {
    return "-";
  }

  return `\u20B9${Number(value).toLocaleString("en-IN")}`;
};

const formatDisplayDate = (value) => {
  if (!value) return "-";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
};

const normalizeEmployeeList = (response, roleOptions) =>
  extractCollection(response).map((emp) => {
    const fullName = `${emp.firstName ?? ""} ${emp.lastName ?? ""}`.trim();
    const matchedRole =
      roleOptions.find(
        (role) => String(role.roleId) === String(emp.roleId ?? emp.role_Id ?? "")
      ) ||
      roleOptions.find(
        (role) =>
          String(role.roleName).toLowerCase() ===
          String(emp.roleName ?? emp.role ?? "").toLowerCase()
      );

    const rawCtc =
      emp.ctc === null || emp.ctc === undefined || emp.ctc === ""
        ? ""
        : String(emp.ctc);
    const joinedValue = emp.joiningDate
      ? String(emp.joiningDate).split("T")[0]
      : "";

    return {
      id: emp.employee_id ?? emp.employee_Id ?? emp.employeeId ?? "-",
      name: emp.name || fullName || "-",
      email: emp.email ?? "-",
      dept: emp.department ?? emp.dept ?? "-",
      ctcRaw: rawCtc,
      ctc: formatCurrency(rawCtc),
      role: matchedRole?.roleName || emp.roleName || emp.role || "-",
      roleId: matchedRole?.roleId || emp.roleId || emp.role_Id || "",
      status: emp.status ?? "-",
      joinedValue,
      joined: formatDisplayDate(joinedValue),
      salarySource: emp,
    };
  });

function EmployeeList() {
  const navigate = useNavigate();

  const [empList, setEmpList] = useState([]);
  const [empSearch, setEmpSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [sortBy, setSortBy] = useState("name-asc");

  const [empShowModal, setEmpShowModal] = useState(false);
  const [showDeptModal, setShowDeptModal] = useState(false);
  const [showRoleModal, setShowRoleModal] = useState(false);
  const [showDeletePopup, setShowDeletePopup] = useState(false);
  const [employeeToDelete, setEmployeeToDelete] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [departments, setDepartments] = useState([]);
  const [roles, setRoles] = useState([]);
  const [message, setMessage] = useState("");
  const [messageType, setMessageType] = useState("");
  const [newDept, setNewDept] = useState("");
  const [newRole, setNewRole] = useState("");
  const [errors, setErrors] = useState({});
  const [empForm, setEmpForm] = useState(initialEmployeeForm);
  const {
    ctcValue: employeeCtcValue,
    salaryBreakup,
    manualSalaryFields,
    salaryErrors,
    isSalaryValid: isEmployeeSalaryValid,
    isSyncingSalary: isEmployeeSalarySyncing,
    handleCtcChange: handleEmployeeCtcChange,
    resetSalaryStructure: resetEmployeeSalaryStructure,
  } = useSalaryStructure({
    initialCtc: SALARY_MIN,
    calculateEndpoint: API_ENDPOINTS.offerLetters.calculateBreakup,
  });

  const isEditMode = Boolean(empForm.originalId);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [roleRes, empRes, deptRes] = await Promise.all([
          api.get(API_ENDPOINTS.masters.roles.list),
          api.get(API_ENDPOINTS.employees.list),
          api.get(API_ENDPOINTS.departments.list),
        ]);

        const roleOptions = normalizeRoleOptions(roleRes);
        const departmentOptions = normalizeDepartmentOptions(deptRes);

        setRoles(roleOptions);
        setDepartments(departmentOptions);
        setEmpList(normalizeEmployeeList(empRes, roleOptions).reverse());
      } catch (err) {
        console.error("Data load error:", err);
        setMessage("Unable to load employees.");
        setMessageType("error");
      }
    };

    loadData();
  }, []);

  useEffect(() => {
    if (!message) return undefined;

    const timer = setTimeout(() => {
      setMessage("");
    }, 3000);

    return () => clearTimeout(timer);
  }, [message]);

  useEffect(() => {
    if (!isEmployeeSalaryValid && !errors.ctc) {
      return;
    }

    if (isEmployeeSalaryValid && errors.ctc) {
      setErrors((prev) => ({
        ...prev,
        ctc: "",
      }));
    }
  }, [errors.ctc, isEmployeeSalaryValid]);

  const fetchEmployees = async (roleOptions = roles) => {
    try {
      const res = await api.get(API_ENDPOINTS.employees.list);
      setEmpList(normalizeEmployeeList(res, roleOptions).reverse());
    } catch (err) {
      console.error("Employee fetch error:", err.response?.data || err.message);
      setMessage("Unable to refresh employees.");
      setMessageType("error");
    }
  };

  const handleEmpChange = (event) => {
    const { name, value } = event.target;

    setEmpForm((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const resetEmployeeForm = () => {
    setEmpForm(initialEmployeeForm);
    setErrors({});
    resetEmployeeSalaryStructure({ ctcAnnual: SALARY_MIN });
  };

  const openAddEmployeeModal = () => {
    resetEmployeeForm();
    setEmpShowModal(true);
  };

  const openEditEmployeeModal = (emp) => {
    setErrors({});
    setEmpForm({
      id: emp.id,
      originalId: emp.id,
      name: emp.name === "-" ? "" : emp.name,
      email: emp.email === "-" ? "" : emp.email,
      dept: emp.dept === "-" ? "" : emp.dept,
      roleId: emp.roleId,
      status: emp.status === "-" ? "" : emp.status,
      joined: emp.joinedValue,
    });
    resetEmployeeSalaryStructure({
      ctcAnnual: Number(emp.ctcRaw || SALARY_MIN),
      source: emp.salarySource,
    });
    setEmpShowModal(true);
  };

  const validateEmployee = () => {
    const nextErrors = {};

    if (!empForm.id.trim()) {
      nextErrors.id = "Employee ID is required";
    } else if (!isEditMode) {
      const idExists = empList.some(
        (emp) => String(emp.id).toLowerCase() === empForm.id.trim().toLowerCase()
      );

      if (idExists) {
        nextErrors.id = "Employee ID already exists.";
      }
    }

    if (!empForm.name.trim()) {
      nextErrors.name = "Employee name is required";
    }

    if (!empForm.email.trim()) {
      nextErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(empForm.email)) {
      nextErrors.email = "Invalid email format";
    } else if (!isEditMode) {
      const emailExists = empList.some(
        (emp) => String(emp.email).toLowerCase() === empForm.email.trim().toLowerCase()
      );

      if (emailExists) {
        nextErrors.email = "Email already exists.";
      }
    }

    if (!empForm.dept) nextErrors.dept = "Department is required";
    if (!empForm.roleId) nextErrors.roleId = "Role is required";
    if (!empForm.status) nextErrors.status = "Status is required";
    if (!empForm.joined) nextErrors.joined = "Joining date is required";
    if (!isEmployeeSalaryValid) nextErrors.ctc = "Please review the salary structure.";

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleEmployeeSubmit = async () => {
    if (!validateEmployee()) return;

    setIsSubmitting(true);

    try {
      const selectedRole = roles.find(
        (role) => String(role.roleId) === String(empForm.roleId)
      );
      const salaryStructure = buildSalaryBreakupPayload(
        employeeCtcValue,
        salaryBreakup,
        manualSalaryFields
      );

      const payload = {
        employee_Id: empForm.id.trim(),
        name: empForm.name.trim(),
        email: empForm.email.trim(),
        department: empForm.dept,
        roleName: selectedRole?.roleName || "",
        status: empForm.status,
        joiningDate: new Date(`${empForm.joined}T00:00:00`).toISOString(),
        ctc: employeeCtcValue,
        basic: salaryStructure.basic,
        hra: salaryStructure.hra,
        conveyance: salaryStructure.conveyance,
        medicalAllowance: salaryStructure.medicalAllowance,
        otherAllowance: salaryStructure.otherAllowance,
        totalCtc: salaryStructure.totalCtc,
        manualOverrideFields: salaryStructure.manualOverrideFields,
        salaryStructure,
      };

      if (isEditMode) {
        await api.put(API_ENDPOINTS.employees.byId(empForm.id), payload, {
          headers: { "Content-Type": "application/json" },
        });
      } else {
        await api.post(API_ENDPOINTS.employees.list, payload, {
          headers: { "Content-Type": "application/json" },
        });
      }

      setMessage(isEditMode ? "Employee updated successfully." : "Employee added successfully.");
      setMessageType("success");
      setEmpShowModal(false);
      resetEmployeeForm();
      await fetchEmployees();
    } catch (err) {
      console.error("Employee save error:", err.response?.data || err.message);

      const backendMessage =
        err.response?.data?.message ||
        err.response?.data ||
        err.message ||
        "";
      const normalizedMessage = String(backendMessage).toLowerCase();

      if (normalizedMessage.includes("employee")) {
        setMessage("Employee ID already exists.");
      } else if (normalizedMessage.includes("email")) {
        setMessage("Email already exists.");
      } else {
        setMessage(backendMessage || "Failed to save employee.");
      }

      setMessageType("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const confirmDeleteEmployee = async () => {
    if (!employeeToDelete) return;

    try {
      await api.delete(API_ENDPOINTS.employees.byId(employeeToDelete));
      setShowDeletePopup(false);
      setEmployeeToDelete(null);
      setMessage("Employee deleted successfully.");
      setMessageType("success");
      await fetchEmployees();
    } catch (err) {
      console.error("Delete error:", err.response?.data || err.message);
      setMessage("Delete failed.");
      setMessageType("error");
    }
  };

  const handleAddDept = () => {
    if (!newDept.trim()) return;

    if (!departments.some((dept) => dept.departmentName === newDept.trim())) {
      setDepartments((prev) => [
        ...prev,
        { id: newDept.trim(), departmentName: newDept.trim() },
      ]);
    }

    setNewDept("");
  };

  const handleDeleteDept = (dept) => {
    const used = empList.some((emp) => emp.dept === dept);

    if (used) {
      setMessage("Department already assigned to an employee.");
      setMessageType("error");
      return;
    }

    setDepartments((prev) => prev.filter((item) => item.departmentName !== dept));
  };

  const handleAddRole = () => {
    if (!newRole.trim()) return;

    if (!roles.some((role) => role.roleName === newRole.trim())) {
      setRoles((prev) => [
        ...prev,
        { roleId: Date.now(), roleName: newRole.trim() },
      ]);
    }

    setNewRole("");
  };

  const handleDeleteRole = (roleName) => {
    const used = empList.some((emp) => emp.role === roleName);

    if (used) {
      setMessage("Role already assigned to an employee.");
      setMessageType("error");
      return;
    }

    setRoles((prev) => prev.filter((role) => role.roleName !== roleName));
  };

  const departmentOptions = useMemo(() => {
    const values = departments
      .map((dept) => dept.departmentName)
      .filter(Boolean);

    return [...new Set(values)].sort((first, second) => first.localeCompare(second));
  }, [departments]);

  const statusOptions = useMemo(() => {
    const values = empList
      .map((emp) => emp.status)
      .filter((status) => status && status !== "-");

    return [...new Set(values)].sort((first, second) => first.localeCompare(second));
  }, [empList]);

  const filteredEmployees = useMemo(() => {
    const searchText = empSearch.trim().toLowerCase();

    const results = empList.filter((emp) => {
      const matchesSearch =
        !searchText ||
        [emp.name, emp.email, emp.id].some((value) =>
          String(value || "").toLowerCase().includes(searchText)
        );
      const matchesDepartment =
        departmentFilter === "All" || emp.dept === departmentFilter;
      const matchesStatus = statusFilter === "All" || emp.status === statusFilter;

      return matchesSearch && matchesDepartment && matchesStatus;
    });

    return [...results].sort((first, second) => {
      if (sortBy === "name-asc") {
        return first.name.localeCompare(second.name);
      }

      if (sortBy === "joined-desc") {
        return String(second.joinedValue).localeCompare(String(first.joinedValue));
      }

      if (sortBy === "ctc-desc") {
        return Number(second.ctcRaw || 0) - Number(first.ctcRaw || 0);
      }

      return 0;
    });
  }, [departmentFilter, empList, empSearch, sortBy, statusFilter]);

  const emptyStateMessage = useMemo(() => {
    const hasSearch = empSearch.trim().length > 0;
    const hasFilters = departmentFilter !== "All" || statusFilter !== "All";

    if (hasSearch && hasFilters) {
      return "No employees match the current search and filters.";
    }

    if (hasSearch) {
      return "No employees found for this search.";
    }

    if (hasFilters) {
      return "No employees match the selected filters.";
    }

    return "No employees available.";
  }, [departmentFilter, empSearch, statusFilter]);

  return (
    <div className="emp-page-unique">
      {message && <div className={`emp-message ${messageType}`}>{message}</div>}

      <div className="emp-header-unique">
        <div>
          <h2>Employees</h2>
          <p>
            {filteredEmployees.length} shown of {empList.length} employees
          </p>
        </div>

        <div className="emp-header-actions">
          <button className="emp-add-btn" onClick={openAddEmployeeModal}>
            + Add Employee
          </button>
        </div>
      </div>

      <div className="emp-toolbar">
        <input
          className="emp-search-box"
          type="text"
          placeholder="Search by name, email, or ID..."
          value={empSearch}
          onChange={(event) => setEmpSearch(event.target.value)}
        />

        <div className="emp-filter-group">
          <select
            className="emp-filter-select"
            value={departmentFilter}
            onChange={(event) => setDepartmentFilter(event.target.value)}
          >
            <option value="All">All Departments</option>
            {departmentOptions.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>

          <select
            className="emp-filter-select"
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value)}
          >
            <option value="All">All Statuses</option>
            {statusOptions.map((status) => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </select>

          <select
            className="emp-filter-select"
            value={sortBy}
            onChange={(event) => setSortBy(event.target.value)}
          >
            <option value="name-asc">Sort: Name</option>
            <option value="joined-desc">Sort: Newest Join Date</option>
            <option value="ctc-desc">Sort: Highest CTC</option>
          </select>
        </div>
      </div>

      <div className="emp-table-container">
        <table className="emp-table">
          <colgroup>
            <col style={{ width: "220px" }} />
            <col style={{ width: "130px" }} />
            <col style={{ width: "240px" }} />
            <col style={{ width: "150px" }} />
            <col style={{ width: "130px" }} />
            <col style={{ width: "150px" }} />
            <col style={{ width: "150px" }} />
            <col style={{ width: "140px" }} />
            <col style={{ width: "150px" }} />
          </colgroup>
          <thead>
            <tr>
              <th>Employee Name</th>
              <th>Employee ID</th>
              <th>Email</th>
              <th>Department</th>
              <th>CTC</th>
              <th>Role</th>
              <th>Status</th>
              <th>Joined</th>
              <th className="emp-action-col">Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredEmployees.length === 0 ? (
              <tr>
                <td colSpan="9" className="emp-empty-state">
                  {emptyStateMessage}
                </td>
              </tr>
            ) : (
              filteredEmployees.map((emp) => (
                <tr
                  key={emp.id}
                  className="emp-row-click"
                  onClick={() => navigate(`/add-employee/${emp.id}`)}
                >
                  <td className="emp-name-col">
                    <div
                      className="emp-name"
                      title={emp.name}
                      onClick={(event) => {
                        event.stopPropagation();
                        navigate(`/add-employee/${emp.id}`);
                      }}
                    >
                      {emp.name}
                    </div>
                  </td>

                  <td className="emp-id-col">
                    <div className="emp-id-code" title={emp.id}>
                      {emp.id}
                    </div>
                  </td>

                  <td>
                    <span className="emp-cell-truncate" title={emp.email}>
                      {emp.email}
                    </span>
                  </td>
                  <td>{emp.dept}</td>
                  <td>{emp.ctc}</td>
                  <td>{emp.role}</td>
                  <td>{emp.status}</td>
                  <td>{emp.joined}</td>

                  <td className="emp-action-col">
                    <div className="action-btns">
                      <button
                        className="edit-btn"
                        onClick={(event) => {
                          event.stopPropagation();
                          openEditEmployeeModal(emp);
                        }}
                      >
                        Edit
                      </button>
                      <button
                        className="delete-btn"
                        onClick={(event) => {
                          event.stopPropagation();
                          setEmployeeToDelete(emp.id);
                          setShowDeletePopup(true);
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {empShowModal && (
        <div className="emp-modal-overlay">
          <div className="emp-modal-box salary-modal">
            <div className="emp-modal-header">
              <div>
                <h3>{isEditMode ? "Edit Employee" : "Add Employee"}</h3>
                <p className="emp-modal-description">
                  Maintain employee details and set the annual salary structure in
                  one clean workspace.
                </p>
              </div>
            </div>

            <div className="emp-modal-form-grid">
              <div className="emp-field-group">
                <label htmlFor="employee-id-input">Employee ID</label>
                <input
                  id="employee-id-input"
                  name="id"
                  value={empForm.id}
                  onChange={handleEmpChange}
                  placeholder="Ex: P401"
                  disabled={isSubmitting || isEditMode}
                />
                {errors.id && <p className="form-error">{errors.id}</p>}
              </div>

              <div className="emp-field-group">
                <label htmlFor="employee-name-input">Name</label>
                <input
                  id="employee-name-input"
                  name="name"
                  value={empForm.name}
                  onChange={handleEmpChange}
                  placeholder="Enter employee name"
                  disabled={isSubmitting}
                />
                {errors.name && <p className="form-error">{errors.name}</p>}
              </div>

              <div className="emp-field-group">
                <label htmlFor="employee-email-input">Email</label>
                <input
                  id="employee-email-input"
                  name="email"
                  value={empForm.email}
                  onChange={handleEmpChange}
                  placeholder="Enter employee email"
                  disabled={isSubmitting || isEditMode}
                />
                {errors.email && <p className="form-error">{errors.email}</p>}
              </div>

              <div className="emp-field-group">
                <label htmlFor="employee-department-select">Department</label>
                <select
                  id="employee-department-select"
                  name="dept"
                  value={empForm.dept}
                  onChange={handleEmpChange}
                  disabled={isSubmitting}
                >
                  <option value="">Select Department</option>
                  {departments.map((dept) => (
                    <option key={dept.id} value={dept.departmentName}>
                      {dept.departmentName}
                    </option>
                  ))}
                </select>
                {errors.dept && <p className="form-error">{errors.dept}</p>}
              </div>

              <div className="emp-field-group emp-salary-field-group emp-modal-span-2">
                <label>Salary Structure</label>
                <SalaryStructureCard
                  idPrefix="employee-modal"
                  ctcValue={employeeCtcValue}
                  salaryBreakup={salaryBreakup}
                  manualSalaryFields={manualSalaryFields}
                  salaryErrors={salaryErrors}
                  isSyncingSalary={isEmployeeSalarySyncing}
                  disabled={isSubmitting}
                  onCtcChange={handleEmployeeCtcChange}
                  variant="compact"
                  helperText="Choose the annual CTC and the system will calculate the salary breakup automatically."
                />
                {errors.ctc && <p className="form-error">{errors.ctc}</p>}
              </div>

              <div className="emp-field-group">
                <label htmlFor="employee-role-select">Role</label>
                <select
                  id="employee-role-select"
                  name="roleId"
                  value={empForm.roleId}
                  onChange={handleEmpChange}
                  disabled={isSubmitting}
                >
                  <option value="">Select Role</option>
                  {roles.length > 0 ? (
                    roles.map((role) => (
                      <option key={role.roleId} value={role.roleId}>
                        {role.roleName}
                      </option>
                    ))
                  ) : (
                    <option disabled>No roles available</option>
                  )}
                </select>
                {errors.roleId && <p className="form-error">{errors.roleId}</p>}
              </div>

              <div className="emp-field-group">
                <label htmlFor="employee-status-select">Status</label>
                <select
                  id="employee-status-select"
                  name="status"
                  value={empForm.status}
                  onChange={handleEmpChange}
                  disabled={isSubmitting}
                >
                  <option value="">Select Status</option>
                  <option>Ready to Accept Offer</option>
                  <option>Rejected Offer</option>
                  <option>Active</option>
                  <option>Probation</option>
                  <option>InActive</option>
                </select>
                {errors.status && <p className="form-error">{errors.status}</p>}
              </div>

              <div className="emp-field-group emp-modal-span-2">
                <label htmlFor="employee-joined-input">Joining Date</label>
                <input
                  id="employee-joined-input"
                  type="date"
                  name="joined"
                  value={empForm.joined}
                  onChange={handleEmpChange}
                  disabled={isSubmitting}
                />
                {empForm.joined && (
                  <p className="emp-field-helper">
                    Displayed as: {formatDisplayDate(empForm.joined)}
                  </p>
                )}
                {errors.joined && <p className="form-error">{errors.joined}</p>}
              </div>
            </div>

            <div className="emp-modal-btns">
              <button
                className="emp-close-btn"
                onClick={() => setEmpShowModal(false)}
                disabled={isSubmitting}
              >
                Close
              </button>
              <button
                className="emp-save-btn"
                onClick={handleEmployeeSubmit}
                disabled={isSubmitting}
              >
                {isSubmitting
                  ? isEditMode
                    ? "Updating..."
                    : "Saving..."
                  : isEditMode
                    ? "Update"
                    : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeptModal && (
        <div className="emp-modal-overlay">
          <div className="emp-modal-box small">
            <h3>Manage Departments</h3>

            <div className="master-add">
              <input
                value={newDept}
                onChange={(event) => setNewDept(event.target.value)}
                placeholder="New Department"
              />
              <button className="emp-save-btn" onClick={handleAddDept}>
                Add
              </button>
            </div>

            {departments.map((dept) => (
              <div className="master-item" key={dept.id}>
                {dept.departmentName}
                <button onClick={() => handleDeleteDept(dept.departmentName)}>x</button>
              </div>
            ))}

            <div className="emp-modal-btns">
              <button className="emp-close-btn" onClick={() => setShowDeptModal(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {showRoleModal && (
        <div className="emp-modal-overlay">
          <div className="emp-modal-box small">
            <h3>Manage Roles</h3>

            <div className="master-add">
              <input
                value={newRole}
                onChange={(event) => setNewRole(event.target.value)}
                placeholder="New Role"
              />
              <button className="emp-save-btn" onClick={handleAddRole}>
                Add
              </button>
            </div>

            {roles.map((role) => (
              <div className="master-item" key={role.roleId}>
                {role.roleName}
                <button onClick={() => handleDeleteRole(role.roleName)}>x</button>
              </div>
            ))}

            <div className="emp-modal-btns">
              <button className="emp-close-btn" onClick={() => setShowRoleModal(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeletePopup && (
        <div className="emp-delete-overlay">
          <div className="emp-delete-modal">
            <h3>Confirm Delete</h3>

            <p style={{ marginBottom: "35px" }}>
              Are you sure you want to delete this employee?
            </p>

            <div className="emp-delete-actions">
              <button
                className="emp-delete-cancel-btn"
                onClick={() => {
                  setShowDeletePopup(false);
                  setEmployeeToDelete(null);
                }}
              >
                Cancel
              </button>

              <button className="emp-delete-btn" onClick={confirmDeleteEmployee}>
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
           )}
    </div>
  );
}

export default EmployeeList;
